﻿<?php


	$mysql_server_name='localhost'; //Mysql数据库服务器
	
	$mysql_username='mjklcprb'; //Mysql数据库用户名
	
	$mysql_password='1575240667'; //Mysql数据库密码
	
	$mysql_database='mjklcprb'; //Mysql数据库名
?>