<?php
	
	error_reporting(0);
	session_start();
	$_SESSION['conn'] = 'index';
	include 'inc/conn.php';
	header("Content-type: text/html; charset=utf-8");
	mysql_query("set names utf8");
	
	$id = $_GET[id];
	$from = 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
	$_SESSION['token'] = uniqid();
	
	mysql_query("set names utf8");
	$result = mysql_query("SELECT * FROM content where Id ='".$id."'");
	while($row = mysql_fetch_array($result))
	{
	
	if ($row['bgcolor']=='#5bc0de') {
		$btncolor = 'info';
	}elseif($row['bgcolor']=='#428bca') {
		$btncolor = 'primary';
	}elseif($row['bgcolor']=='#5cb85c') {
		$btncolor = 'success';
	}elseif($row['bgcolor']=='#f0ad4e') {
		$btncolor = 'warning';
	}elseif($row['bgcolor']=='#d9534f') {
		$btncolor = 'danger';
	}
	
	$pagesess = 'page'.getenv("REMOTE_ADDR").date("YmdH");
	if($_SESSION[$ssearsess]){
		$fhlist = $_SESSION[$pagesess];
	}else{
		$fhlist = 'index.php';
	}
	
	$sql = "select * from system";//查询数据库
	$set = mysql_query($sql);
	$result = mysql_fetch_array($set);
	
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>内容丨<?php echo $result['title']?></title>
		<meta name="keywords" content="<?php echo $result['webkey'];?>">
		<meta name="description" content="<?php echo $result['webdes'];?>">
		<meta itemprop="name" content="内容丨<?php echo $result['title']?>">  
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/style.css" />
		<script type="text/javascript" src="js/jquery.min.js" ></script>
		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
		<script type="text/javascript" >
			function com(){
				var inputtext = document.getElementById("textinput");
				var inputbtn = document.getElementById("btninput");
				inputtext.style.width="79%";
				inputtext.style.marginRight="1%";
				inputbtn.style.width="18%";
				inputbtn.style.display="block";
				inputtext.style.float="left";
				inputbtn.style.float="right";
			}
			function none(){
				var inputtext = document.getElementById("textinput");
				var inputbtn = document.getElementById("btninput");
				inputtext.style.width="98%";
				inputbtn.style.display="none";
			}
			var speaks = 1;
			function btndis(){
				if(speaks==2){
            		document.getElementById("btninput").disabled = 'disabled';
            	}
            	++speaks;
			}
		</script>
	</head>
	<body>
		
			<div class="cont-body">
				<div class="cont-body-cont" style="background-color: <?=$row['bgcolor']?>;">
					<div class="index-list-imgdiv">
						<img src="<?=$row['img']?>" class="index-list-img" />
					</div>
					<div class="index-list-content">
						<p class="index-list-content-p">
							<?=$row['cont']?>
						</p>
					</div>
					<div class="index-list-foot">
						<span class="foot-left dianzan">赞<?=$row['zan']?></span>
						<span class="foot-left">评论<?=$row['comt']?></span>
						<a href="#srtext"><span class="foot-right glyphicon glyphicon-comment"></span></a>
						<a href="javascript:;" class="dza" rel="<?=$row['Id']?>" onclick="dianzan()"><span id="dzspan" class="foot-right glyphicon glyphicon-thumbs-up" style="color: <?php
						$id = $row['Id'];
						$ip = $_SERVER["REMOTE_ADDR"];
						$sql1 = "select * from handle where cid='$id' and ip='$ip'"; //更新数据
						$result1 = mysql_query($sql1);	
						if (mysql_num_rows($result1)) {
							echo "#018EE8";
						}
						?>;"></span></a>
					</div>
				</div>
			</div>
			<script type="text/javascript" src="js/dianzan.js" ></script>
			<div class="comment" >
				<div class="comment-top">
					<p>精彩评论</p>
				</div>
				<hr class="comment-hr"/>
				<table class="comment-table">
					<?php
						mysql_query("set names utf8");
						$result1 = mysql_query("SELECT * FROM comment where contid = '".$id."' order by Id asc limit 99999");
						while($row1 = mysql_fetch_array($result1))
						{
				    ?>
					<tr>
						<td class="comment-img" rowspan='2'>
							<img src="<?=$row1['plimg']?>" />
						</td>
						<td class="comment-time"><?=$row1['floor']?>#&nbsp;&nbsp;<?=$row1['pltime']?></td>
					</tr>
					<tr>
						<td class="comment-cont">
							<p><?=$row1['cont']?></p>
						</td>
					</tr>
					<?php
					   	}
					?>
				</table>
			</div>
			<div class="index-list-footer">
<div class="index-top-btn" align="center">
					<a href="<?php echo $fhlist;?>" class="btn btn-default">
						<span>返回列表</span>
					</a>
				</div>
			</div>
		</div>
		<div class="comment-foot">
			<div class="comment-foot-bg"></div>
			<form action="submit.php" method="post" style="margin: 0px;padding: 0px;z-index: 999;">
				<input name="form" style="display: none;" value="comt" />
				<input name="token" style="display: none;" value="<?php echo $_SESSION['token']?>" />
				<input name="from" style="display: none;" value="<?php echo $from;?>" />
				<input name="floor" style="display: none;" value="<?=$row['comt']?>" />
				<input name="plimg" style="display: none;" value="img/head/<?php echo mt_rand(1,21);?>.png" />
				<input name="contid" style="display: none;" value="<?php echo $_GET['id'];?>" />
				<input name="cont" type="text"  onclick="com()" placeholder="评论..." class="form-control" id="textinput" required oninvalid="setCustomValidity('内容不可为空...')" oninput="setCustomValidity('')" autofocus="" style="width: 98%;margin-left: 1%;"/>
				<input type="submit" value="发表" class="btn btn-default" id="btninput" onclick="btndis()" style="display: none;margin-right: 1%;" />
			</form>
		</div>
		<?php
			}
		?>		
		<div id="goTopBtn"></div>
		<script type="text/javascript" >
			$(window).scroll(function(){
		     var sc=$(window).scrollTop();
		     var rwidth=$(window).width()
		         if(sc>0){
		    $("#goTopBtn").css("display","block");
		    $("#goTopBtn").css("margin-left","-1%");
		    $("#goTopBtn").css("left",(rwidth-41)+"px")
		    }else{
			$("#goTopBtn").css("display","none");
		    }
		    })
			$("#goTopBtn").click(function(){
		    var sc=$(window).scrollTop();
			$('body,html').animate({scrollTop:0},500);
		    })  
		</script>
	</body>
	<script type="text/javascript" src="js/bootstrap.min.js" ></script>
	</body>
</html>
