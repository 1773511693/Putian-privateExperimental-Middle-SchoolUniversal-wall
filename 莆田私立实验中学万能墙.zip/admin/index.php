<?php

	error_reporting(0);
	session_start();
	$_SESSION['conn'] = 'admin';
	include '../inc/conn.php';
	include 'sql.php';
	mysql_query("set names utf8");
	
	if (!isset ($_SESSION['login'])) { 
		echo '<script>location.href="login.php"</script>';
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>首页丨后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../css/amdin.css" />
		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
		<script type="text/javascript" src="../js/jquery.min.js" ></script>
	</head>
	<body id="body">
		<div class="navbar navbar-inverse">
		    <div class="navbar-header">
			    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			    </button>
			    <a class="navbar-brand" href="index.php">后台管理系统</a>
		    </div>
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		        <ul class="nav navbar-nav">
		            <a class="btn btn-primary nav_btn" href="index.php">后台首页</a>
		            <a class="btn btn-primary nav_btn" href="../index.php" target="_blank">网站首页</a>
		            <a class="btn btn-success nav_btn" href="cont.php">内容管理</a>
		            <a class="btn btn-success nav_btn" href="speak.php">评论管理</a>
		            <a class="btn btn-success nav_btn" href="system.php">系统设置</a>
		            <a class="btn btn-success nav_btn" href="password.php">密码修改</a>
		            <?php
						$a=$_REQUEST["a"];
						if ($a=="off")
						{
							unset ($_SESSION['login']);
							header('Location:login.php');
						}
					?>
		            <form method="post" action="">
					<input type="submit" class="btn btn-warning nav_btn_off" href="#" value="登出后台">
					<input name="a" type="hidden" id="a" value="off" style="display: none;width: 0px;height: 0px;" />
					</form>
		        </ul>
		    </div>
		</div>
		<div class="body" align="center">
			<div class="bodydiv">
				<div class="alert alert-danger index_count">
					<div class="index_count_1">
						<p class="index_count_num"><?php echo $cntcont;?>条</p>
						<p class="index_count_name">内容总数</p>
					</div>
					<div class="index_count_2">
						<p class="index_count_num"><?php echo $cntspk;?>条</p>
						<p class="index_count_name">评论总数</p>
					</div>
					<div class="index_count_3">
						<p class="index_count_num"><?php echo $rowzan[0];?>次</p>
						<p class="index_count_name">点赞总数</p>
					</div>
				</div>
				<div class="alert alert-danger index_about" align="left">
					<label class="form-control">版　本：Beta-0.1.2</label>
					
				</div>
			</div>
		</div>
		<div class="index_footer">
			<p class="index_footer_p" align="center"> <?php
date_default_timezone_set("PRC");
echo date("Y");
?>Power by 木槿开发♥感谢墙墙的使用QQ1773511693</p>
		</div>
		<script type="text/javascript" src="../js/bootstrap.min.js" ></script>
	</body>
</html>
