<?php
	
	
	error_reporting(0);
	session_start();
	$_SESSION['conn'] = 'admin';
	include '../inc/conn.php';
	mysql_query("set names utf8");
	
	if (!isset ($_SESSION['login'])) { 
		echo '<script>location.href="login.php"</script>';
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>评论丨后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../css/amdin.css" />
		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
		<script type="text/javascript" src="../js/jquery.min.js" ></script>
	</head>
	<body id="body">
		<div class="navbar navbar-inverse">
		    <div class="navbar-header">
			    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			    </button>
			    <a class="navbar-brand" href="index.php">后台管理系统</a>
		    </div>
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		        <ul class="nav navbar-nav">
		            <a class="btn btn-primary nav_btn" href="index.php">后台首页</a>
		            <a class="btn btn-primary nav_btn" href="../index.php" target="_blank">网站首页</a>
		            <a class="btn btn-success nav_btn" href="cont.php">内容管理</a>
		            <a class="btn btn-success nav_btn" href="speak.php">评论管理</a>
		            <a class="btn btn-success nav_btn" href="system.php">系统设置</a>
		            <a class="btn btn-success nav_btn" href="password.php">密码修改</a>
		            <?php
						$a=$_REQUEST["a"];
						if ($a=="off")
						{
							unset ($_SESSION['login']);
							header('Location:login.php');
						}
					?>
		            <form method="post" action="">
					<input type="submit" class="btn btn-warning nav_btn_off" href="#" value="登出后台">
					<input name="a" type="hidden" id="a" value="off" style="display: none;width: 0px;height: 0px;" />
					</form>
		        </ul>
		    </div>
		</div>
		<div class="body" align="center">
			<div class="bodydiv">
				<label class="form-control cont_name">评论管理</label>
				<div class="cont">
					<?php
						$perNumber = 16; //每页显示记录数
						$page = $_GET['page']; //获得当前页面值
						$count1 = mysql_query("select count(*) from comment"); //获得记录总数
						$rs = mysql_fetch_array($count1);
						$totalNumber = $rs[0];
		
						$totalPage = ceil($totalNumber/$perNumber);
						if (!isset($page)) {
							$page = 1;
						}
						$startCount = ($page-1)*$perNumber;
						$result = mysql_query("select * from comment order by id desc limit $startCount,$perNumber"); //根据前面计算出开始记录和记录数
						while ($row=mysql_fetch_array($result))
						{
				    ?>
					<div class="speak_div">
						<div class="speak_div_top">
							<img src="../<?=$row['plimg']?>" />
							<a target="_blank" href="../cont.php?id=<?=$row['contid']?>"><?=$row['floor']?>楼</a>
							<span><?=$row['pltime']?></span>
						</div>
						<div class="speak_div_cont">
							<p><?=$row['cont']?></p>
						</div>
						<div class="speak_div_btn">
							<a href="del.php?from=speak&id=<?=$row['Id']?>" class="btn btn-success">删除</a>
						</div>
					</div>
					<?php
					   }
					?>
					<div class="pagediv">
						<a class="btn btn-default pagebtn" href="cont.php?page=1">首页</a>
						<a class="btn btn-default pagebtn" id="pagebtn-s" href="cont.php?page=<?php echo $page - 1;?>">上页</a>
						<a class="btn btn-default pagebtn"><?php echo $page ?>/<?php echo $totalPage ?></a>
						<a class="btn btn-default pagebtn" id="pagebtn-x" href="cont.php?page=<?php echo $page + 1;?>">下页</a>
						<a class="btn btn-default pagebtn" href="cont.php?page=<?php echo $totalPage;?>">尾页</a>
					</div>
				</div>
			</div>
		</div>
		<div class="index_footer">
			<p class="index_footer_p" align="center">版权所有 &copy;  <?php
date_default_timezone_set("PRC");
echo date("Y");
?>感谢墙墙的使用</p>
		</div>
		<script type="text/javascript" src="../js/bootstrap.min.js" ></script>
	</body>
</html>
