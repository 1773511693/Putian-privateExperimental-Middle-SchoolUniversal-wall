<?php
	
	error_reporting(0);
	session_start();
	$_SESSION['conn'] = 'admin';
	include '../inc/conn.php';
	mysql_query("set names utf8");
	
	$username = $_POST['username'];//获取登录表单信息
	$password = md5($_POST['password']);//获取登录表单信息
	$sql = "select * from admin where user = '".$username."'";//查询数据库
	$set = mysql_query($sql);
	$result = mysql_fetch_array($set);
	if($result[pass] == $password){
		$_SESSION['login'] = $username;
		echo "<script>location.href='index.php';</script>";
	}
	mysql_close($con); //关闭数据库连接
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>登录丨匿言后台管理系统</title>
		<link rel="stylesheet" href="../css/amdin.css" />
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
	</head>
	<body id="body">
		<div class="login">
			<form action="" method="post" class="login_form">
				<div class="form-group">
			        <input type="text" name="username" class="form-control" placeholder="请输入管理员账号...">
			    </div>
				<div class="form-group">
				    <input type="password" name="password" placeholder="请输入管理员密码..." class="form-control">
				</div>
				<button type="submit" class="login_btn btn btn-default">后台登陆</button>
			</form>
		</div>
	</body>
</html>