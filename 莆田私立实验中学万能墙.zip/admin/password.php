<?php
	

	error_reporting(0);
	session_start();
	$_SESSION['conn'] = 'admin';
	include '../inc/conn.php';
	mysql_query("set names utf8");
	
	if (!isset ($_SESSION['login'])) { 
		echo '<script>location.href="login.php"</script>';
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>密码丨后台管理系统</title>
		<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css"/>
		<link rel="stylesheet" href="../css/amdin.css" />
		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
		<script type="text/javascript" src="../js/jquery.min.js" ></script>
	</head>
	<body id="body">
		<div class="navbar navbar-inverse">
		    <div class="navbar-header">
			    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			        <span class="sr-only">Toggle navigation</span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			        <span class="icon-bar"></span>
			    </button>
			    <a class="navbar-brand" href="index.php">后台管理系统</a>
		    </div>
		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		        <ul class="nav navbar-nav">
		            <a class="btn btn-primary nav_btn" href="index.php">后台首页</a>
		            <a class="btn btn-primary nav_btn" href="../index.php" target="_blank">网站首页</a>
		            <a class="btn btn-success nav_btn" href="cont.php">内容管理</a>
		            <a class="btn btn-success nav_btn" href="speak.php">评论管理</a>
		            <a class="btn btn-success nav_btn" href="system.php">系统设置</a>
		            <a class="btn btn-success nav_btn" href="password.php">密码修改</a>
		            <?php
						$a=$_REQUEST["a"];
						if ($a=="off")
						{
							unset ($_SESSION['login']);
							header('Location:login.php');
						}
					?>
		            <form method="post" action="">
					<input type="submit" class="btn btn-warning nav_btn_off" href="#" value="登出后台">
					<input name="a" type="hidden" id="a" value="off" style="display: none;width: 0px;height: 0px;" />
					</form>
		        </ul>
		    </div>
		</div>
		<div class="body" align="center">
			<div class="bodydiv">
				<label class="form-control cont_name">密码修改</label>
				<div class="cont_form">
					<form action="submit.php" method="post">
						<input value="pass" name="from" style="display: none;"/>
						<div class="form-group">
						    <label for="firstname" class="control-label">旧密码</label>
						    <div class="forminput">
						    	<input placeholder="请输入旧密码..." required="" autofocus="" value="" name="oldpswd" type="text" class="form-control" id="firstname">
							</div>
						</div>
						<div class="form-group">
						    <label for="firstname" class="control-label">新密码</label>
						    <div class="forminput">
						    	<input placeholder="请输入新密码..." required="" autofocus="" value="" name="newpswd" type="text" class="form-control" id="firstname">
							</div>
						</div>
						<div class="form-group">
						    <label for="firstname" class="control-label">重复新密码</label>
						    <div class="forminput">
						    	<input placeholder="请重复输入新密码..." required="" autofocus="" value="" name="newpswd2" type="text" class="form-control" id="firstname">
							</div>
						</div>
						<div class="form-group">
						    <div class="inputbtn">
						    	<input type="submit" class="btn btn-default w100" value="提交"/>
						    </div>
						</div>
					</form>
				</div>
			</div>
		</div>
		<div class="index_footer">
			<p class="index_footer_p" align="center">版权所有 &copy;  <?php
date_default_timezone_set("PRC");
echo date("Y");
?>♥感谢墙墙的使用</p>
		</div>
		<script type="text/javascript" src="../js/bootstrap.min.js" ></script>
	</body>
</html>
