<?php
	
	
	error_reporting(0);
	session_start();
	$_SESSION['conn'] = 'index';
	include 'inc/conn.php';
	header("Content-type: text/html; charset=utf-8");
	mysql_query("set names utf8");

	$a=array("#5bc0de","#428bca","#5cb85c","#f0ad4e","#d9534f"); 
	$random_keys=array_rand($a,2);
	
	$_SESSION['token'] = uniqid();
	$pagesess = 'page'.getenv("REMOTE_ADDR").date("YmdH");
	$_SESSION[$pagesess] = "http://".$_SERVER['SERVER_NAME'].":".$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];

	$sql = "select * from system";//查询数据库
	$set = mysql_query($sql);
	$result = mysql_fetch_array($set);

?>
<!DOCTYPE html>
<html>


		<meta charset="UTF-8">
		<title><?php echo $result['title'];?>丨<?php echo $result['title2'];?></title>
		<meta name="keywords" content="<?php echo $result['webkey'];?>">
		<meta name="description" content="<?php echo $result['webdes'];?>">
		<meta itemprop="name" content="<?php echo $result['title']?>丨<?php echo $result['title2']?>">  
		<link rel="stylesheet" href="css/bootstrap.min.css" />
		<link rel="stylesheet" href="css/style.css" />
		<script type="text/javascript" src="js/jquery.min.js" ></script>
		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta name="viewport" content="width=device-width,height=device-height,inital-scale=1.0,maximum-scale=1.0,user-scalable=no;">
		<script type="text/javascript" >
			function fabu(){
				var inputbtn = document.getElementById("formdiv");
				inputbtn.style.display="block";
			}
			function quxiao(){
				var inputbtn = document.getElementById("formdiv");
				inputbtn.style.display="none";
			}
			function imgtx(){
				var img = document.getElementById('tximgimg').getAttribute("src");
				document.getElementById('imginput').setAttribute("value",img);
			}
			function oneSubmit(){
			    document.forms[0].submit();
			    document.getElementById('fabubtn').disable='disable';
			}
			function pagebtn(){
				var page = GetQueryString("page");
				if(page<="1"||page==""){
					$("#pagebtn-s").attr("disabled", true); 
				}
				if(page>="<?php echo $totalPage ?>"){
					$("#pagebtn-x").attr("disabled", true); 
				}
				if("<?php echo $totalPage ?>"=="1"){
					$("#pagebtn-s").attr("disabled", true); 
					$("#pagebtn-x").attr("disabled", true); 
				}
			}
		</script>
	</head>
	<body onload="pagebtn()">
		



<head>
<meta http-equiv="Content-Language" content="zh-cn" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
.style1 {
	text-align: center;
	font-size: xx-large;
	color: #0000FF;
}
.style2 {
	text-align: center;
	font-size: small;
	color: #0000FF;
}
</style>
</head>

<body>

<p class="style1" align="center"><strong>莆田私立实验中学万能墙</strong></p>
<p class="style2">万能墙QQ1090067942网址ptslsyzx.mjkj6.top</p>


</p>
<p class="style2" align="center" ><b><font size="4"><a href="https://wwx.lanzoux.com/b09fj77yh">
点击下载万能墙APP</a></font></b></p>

<td>
<script language="JavaScript">day=new Date()
nge_Hour=day.getHours()
var nge_warmprompt="";if(nge_Hour==0)nge_warmprompt="现在已经过凌晨了，身体是无价的资本喔，早点休息吧！"
if(nge_Hour==1)nge_warmprompt="凌晨1点多了，工作是永远都做不完的，别熬坏身子！"
if(nge_Hour==2)nge_warmprompt="该休息了，身体可是革命的本钱啊！"
if(nge_Hour==3)nge_warmprompt="夜深了，熬夜很容易导致身体内分泌失调，长痘痘的！"
if(nge_Hour==4)nge_warmprompt="四点过了，你明天不上班？？？"
if(nge_Hour==5)nge_warmprompt="你知道吗，此时是国内网络速度最快的时候！"
if(nge_Hour==6)nge_warmprompt="清晨好，这麽早就上论坛啦，昨晚做的梦好吗？ "
if(nge_Hour==7)nge_warmprompt="新的一天又开始了，祝你过得快乐!"
if(nge_Hour==8)nge_warmprompt="早上好，一天之际在于晨，又是美好的一天！"
if((nge_Hour==9)||(nge_Hour==10))nge_warmprompt="上午好！今天你看上去好精神哦！"
if((nge_Hour==11)||(nge_Hour==12))nge_warmprompt="该吃午饭啦！有什么好吃的？您有中午休息的好习惯吗？"
if((nge_Hour>=13)&&(nge_Hour<=17))nge_warmprompt="下午好！外面的天气好吗？记得朵朵白云曾捎来朋友殷殷的祝福。"
if((nge_Hour>=17)&&(nge_Hour<=18))nge_warmprompt="太阳落山了！快看看夕阳吧！如果外面下雨，就不必了 ^_^"
if((nge_Hour>=18)&&(nge_Hour<=19))nge_warmprompt="晚上好，今天的心情怎么样，来论坛和我们诉说吧！"
if((nge_Hour>=19)&&(nge_Hour<=21))nge_warmprompt="忙碌了一天，累了吧？来玩玩应用游戏，放松下吧！"
if((nge_Hour>=22)&&(nge_Hour<=23))nge_warmprompt="这么晚了，还在上网？早点洗洗睡吧，睡前记得洗洗脸喔！"
document.write("　　<b style='color:#12FF00'>『温馨提示』")
document.write(nge_warmprompt)
document.write("</b>")</script>
</td></p>



<!-- 时间代码begin -->
更新时间：
<p id="lanrenzhijia2">
<script>
Date.prototype.Format = function (fmt) { //javascript时间日期函数
    var o = {
        "M+": this.getMonth() + 1, //月份 
        "d+": this.getDate(), //日 
        "h+": this.getHours(), //小时 
        "m+": this.getMinutes(), //分 
        "s+": this.getSeconds(), //秒 
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度 
        "S": this.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};


	 var time2 = new Date().Format("yyyy-MM-dd hh:mm:ss"); //获取日期，格式： 年-月-日 时-分-秒
		document.getElementById('lanrenzhijia2').innerHTML = time2;  //将时间赋值给t2
</script>
<!-- 时间代码end -->








		</div>
<div class="index-top-btn" align="center">
				<a href="javascript:;" onclick="fabu();imgtx();" class="btn btn-default">
					-----发布新帖-----
				</a>
			</div>
		
		<div id="goTopBtn"></div>
		<script type="text/javascript">
			$(window).scroll(function(){
			    var sc=$(window).scrollTop();
			    var rwidth=$(window).width()
		        if(sc>0){
				    $("#goTopBtn").css("display","block");
				    $("#goTopBtn").css("margin-left","-1%");
				    $("#goTopBtn").css("left",(rwidth-41)+"px")
				}else{
					$("#goTopBtn").css("display","none");
			    }
		    })
			$("#goTopBtn").click(function(){
			    var sc=$(window).scrollTop();
				$('body,html').animate({scrollTop:0},500);
		    })  
		</script>
		<script type="text/javascript">
			var cha=document.getElementById('tximg');
			var imgs=document.getElementsByTagName('img');
			var imginput=document.getElementById('imginput');
			cha.onclick=function (){
				var rand=Math.ceil(Math.random()*21);
				imgs[0].src="img/head/"+rand+".png";
				var img = document.getElementById('tximgimg').getAttribute("src");
				document.getElementById('imginput').setAttribute("value",img);
			}
		</script>
	</body>
	<script type="text/javascript" src="js/bootstrap.min.js" ></script>
</html>








</body>

</html>

		
		<!--发布提交Form-->
		<div class="sayform" id="formdiv">
			<div class="sayform-top">
				<span class="sayform-top-span">发帖</span>
			</div>
			<div class="sayform-cont" align="center">
				<form action="submit.php" method="post" class="form-form">
				<img name="tximgimg" id="tximgimg" src="img/head/<?php echo mt_rand(1,21);?>.png" width="100px" height="100px"/><br />
				<input name="form" style="display: none;" value="tijiao"/>
				<input name="token" style="display: none;" value="<?php echo $_SESSION['token']?>" />
				<input name="bgcolor" style="display: none;" value="<?php echo $a[$random_keys[1]];?>"/>
				<input name="imginput" id="imginput" value="" style="display: none;"/>
				<input id="tximg" type="button" value="更换头像" class="form-control" /><br />
				<textarea name="content" rows="6" required oninvalid="setCustomValidity('内容不可为空...')" oninput="setCustomValidity('')" class="form-control form-text" maxlength="60" placeholder="请输入您要发布的内容..."></textarea><br />
				<input type="submit" id="fabubtn" oneSubmit() value="发布" class="form-control form-btn"/>
				<a href="javascript:;" onclick="quxiao()" class="form-control form-btn1">取消</a>
			</form>
			</div>
		</div>
		<!--发布提交Form-->
		
		<div class="index-list">
			<?php
				$perNumber = 16; //每页显示记录数
				$page = $_GET['page']; //获得当前页面值
				$count1 = mysql_query("select count(*) from content"); //获得记录总数
				$rs = mysql_fetch_array($count1);
				$totalNumber = $rs[0];

				$totalPage = ceil($totalNumber/$perNumber);
				if (!isset($page)) {
					$page = 1;
				}
				$startCount = ($page-1)*$perNumber;
				$result = mysql_query("select * from content order by id desc limit $startCount,$perNumber"); //根据前面计算出开始记录和记录数
				while ($row=mysql_fetch_array($result))
				{
		    ?>
			<a href="cont.php?id=<?=$row['Id']?>">
			<div class="index-list-cont" style="background-color: <?=$row['bgcolor']?>;">
				<div class="index-list-imgdiv">
					<img src="<?=$row['img']?>" class="index-list-img" />
				</div>
				<div class="index-list-content">
					<p class="index-list-content-p">
						<?=$row['cont']?>
					</p>
				</div>
				<div class="dzdiv index-list-foot">
					<span class="foot-left dianzan" id="dianzan">赞<?=$row['zan']?></span>
					<span class="foot-left">评论<?=$row['comt']?></span>
						
                    	<a href="javascript:;" class="sharebtn"><span class="foot-right glyphicon glyphicon-share-alt"></span></a>
                    
                    
					<a href="cont.php?id=<?=$row['Id']?>"><span class="foot-right glyphicon glyphicon-comment"></span></a>
					<a href="javascript:;" class="dza" rel="<?=$row['Id']?>" onclick="dianzan()"><span class="foot-right glyphicon glyphicon-thumbs-up" id="<?=$row['Id']?>"
					style="color: <?php
						$id = $row['Id'];
						$ip = $_SERVER["REMOTE_ADDR"];
						$sql1 = "select * from handle where cid='$id' and ip='$ip'"; //更新数据
						$result1 = mysql_query($sql1);
						if (mysql_num_rows($result1)) {
							echo "#018EE8";
						}
					?>;"></span></a>
				</div>
			</div>
			</a>
			<?php
			   }
			?>
			<script type="text/javascript" src="js/dianzan.js" ></script>
			<div class="pagediv">
				<a class="btn btn-default pagebtn" href="index.php?page=1">首页</a>
				<a class="btn btn-default pagebtn" id="pagebtn-s" href="index.php?page=<?php echo $page - 1;?>">上页</a>
				<a class="btn btn-default pagebtn"><?php echo $page ?>/<?php echo $totalPage ?></a>
				<a class="btn btn-default pagebtn" id="pagebtn-x" href="index.php?page=<?php echo $page + 1;?>">下页</a>
				<a class="btn btn-default pagebtn" href="index.php?page=<?php echo $totalPage;?>">尾页</a></p></p>
			</div>
		
<!-- 下面是广告位 -->


<body>

<p class="style7" align="center">【注意】请尊重本墙，请不要使用恶搞方法糊弄同学朋友</p>
<p class="style4" align="center">
本万能墙所有数据由网友提供，本墙不作任何解释</p>
<p class="style5" align="center">
如有冒犯 后台联系删除</p>
<p class="style8" align="center">
需要租广告位也可以联系我！</p>

<p class="style9" align="center">
欢迎关注微信公众号：木槿网络工作室

<!-- 自己的广告开始腾讯王卡 -->
<p>
<a href="https://v.qq.com/x/page/h3106la7xc2.html" target="_blank"><img src="http://ptslsyzx.mjkj6.top/txwk.png" width="100%" height="65" alt="" />
<!-- 自己的广告结束腾讯王卡 -->
<p class="style2" align="center">管理员QQ1773511693</p>
<p class="style5" align="center">如果你学校也想搭建本网址请联系我!</p>
<p class="style6" align="center">有后台管理系统，有app！</p>

 Power by 木槿|<?php
date_default_timezone_set("PRC");
echo date("Y");
?>
</body>

